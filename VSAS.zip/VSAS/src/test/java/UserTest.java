import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class UserTest {

    private User regularUser;
    private User adminUser;
    private User guestUser;

    @BeforeEach
    public void setUp() {
        regularUser = new User("John", "Doe", "john@example.com", "1234567890", "uniqueID", "johndoe", "hashedPassword123", User.UserType.USER);
        adminUser = new User("admin", "adminpass", User.UserType.ADMIN);
        guestUser = new User(User.UserType.GUEST);
    }

    @Test
    public void testRegularUserFullName() {
        assertEquals("John Doe", regularUser.getFullName());
    }

    @Test
    public void testAdminUserFullName() {
        assertEquals("Admin", adminUser.getFullName());
    }

    @Test
    public void testGuestUserFullName() {
        assertEquals("Guest", guestUser.getFullName());
    }

    @Test
    public void testGetters() {
        assertEquals("johndoe", regularUser.getUsername());
        assertEquals("john@example.com", regularUser.getEmail());
        assertEquals("1234567890", regularUser.getPhoneNumber());
        assertEquals("uniqueID", regularUser.getIdKey());
        assertEquals("hashedPassword123", regularUser.getHashedPassword());
        assertEquals("User", regularUser.getUserType());
        assertEquals("Admin", adminUser.getUserType());
        assertEquals("Guest", guestUser.getUserType());
    }

    @Test
    public void testSetters() {
        regularUser.setFirstName("Jane");
        assertEquals("Jane Doe", regularUser.getFullName());

        regularUser.setLastName("Smith");
        assertEquals("Jane Smith", regularUser.getFullName());

        regularUser.setEmail("jane@example.com");
        assertEquals("jane@example.com", regularUser.getEmail());

        regularUser.setPhoneNumber("0987654321");
        assertEquals("0987654321", regularUser.getPhoneNumber());

        regularUser.setUsername("janesmith");
        assertEquals("janesmith", regularUser.getUsername());

        regularUser.setHashedPassword("newHashedPassword");
        assertEquals("newHashedPassword", regularUser.getHashedPassword());
    }

    @Test
    public void testToString() {
        String expectedString = "johndoe,hashedPassword123,1234567890,john@example.com,John,Doe,uniqueID,USER";
        assertEquals(expectedString, regularUser.toString());
    }

    @Test
    public void testAdminToString() {
        String expectedString = "admin,adminpass,null,null,Admin,null,Admin,ADMIN";
        assertEquals(expectedString, adminUser.toString());
    }

    @Test
    public void testGuestToString() {
        String expectedString = "null,null,null,null,Guest,null,Guest,GUEST";
        assertEquals(expectedString, guestUser.toString());
    }

    @Test
    public void testProfileDisplay() {
        String expectedString = "Name: John Doe, Username: johndoe, Password: hashedPassword123, Phone Numer: 1234567890, Email: john@example.com, User Type: User";
        assertEquals(expectedString, regularUser.profileDisplay());
    }
}
