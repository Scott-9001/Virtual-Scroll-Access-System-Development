import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class ScrollTest {

    private Scroll scroll;

    @BeforeEach
    void setUp() {
        scroll = new Scroll("Scroll1", "123", "Text", "Scott123");
    }

    @Test
    void testScrollCreation() {
        assertEquals("Scroll1", scroll.getName());
        assertEquals("123", scroll.getScrollId());
        assertEquals("Text", scroll.getOriginalType());
        assertEquals("Scott123", scroll.getUploaderId());
        assertEquals(LocalDate.now(), scroll.getUploadDate());
        assertEquals(0, scroll.getDownloadCount());
    }

    @Test
    void testScrollLoadingValidDate() {
        Scroll loadedScroll = new Scroll("Scroll1", "456", "Text", "Scott123", "2023-05-10", "5");
        assertEquals("Scroll1", loadedScroll.getName());
        assertEquals("456", loadedScroll.getScrollId());
        assertEquals("Text", loadedScroll.getOriginalType());
        assertEquals("Scott123", loadedScroll.getUploaderId());
        assertEquals(LocalDate.of(2023, 5, 10), loadedScroll.getUploadDate());
        assertEquals(5, loadedScroll.getDownloadCount());
    }

    @Test
    void testScrollLoadingInvalidDate() {
        Scroll loadedScroll = new Scroll("Scroll1", "456", "Text", "Scott123", "invalid-date", "5");
        assertEquals(LocalDate.now(), loadedScroll.getUploadDate());
    }

    @Test
    void testDownloadCount() {
        scroll.downloadScroll();
        assertEquals(1, scroll.getDownloadCount());
        scroll.downloadScroll();
        assertEquals(2, scroll.getDownloadCount());
    }

    @Test
    void testGetters() {
        assertEquals("Scroll1", scroll.getName());
        assertEquals("123", scroll.getScrollId());
        assertEquals("Text", scroll.getOriginalType());
        assertEquals("Scott123", scroll.getUploaderId());
        assertEquals(LocalDate.now(), scroll.getUploadDate());
        assertEquals(0, scroll.getDownloadCount());
    }

    @Test
    void testToString() {
        String expectedString = "Scroll1,123,Text,Scott123," + LocalDate.now() + ",0";
        assertEquals(expectedString, scroll.toString());
    }

    @Test
    void testViewInfo() {
        String expectedViewInfo = "Scroll1 (ID: 123, Uploaded by: Scott123, Upload Date: " + LocalDate.now() + ")";
        assertEquals(expectedViewInfo, scroll.viewInfo());
    }
}
