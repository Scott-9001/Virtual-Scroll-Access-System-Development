import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Scanner;
import static org.junit.jupiter.api.Assertions.*;

public class AuthenticatorTest {
    private Authenticator authenticator;

    @BeforeEach
    public void setUp() {
        authenticator = new Authenticator();
    }

    @Test
    public void testAdminLoginSuccess() {
        Scanner scanner = new Scanner("admin\nadminpass\n");
        User user = authenticator.loginAdmin(scanner);
        assertNotNull(user, "User should not be null after successful login");
        assertEquals("Admin", user.getUserType(), "User type should be 'Admin'");
    }

    @Test
    public void testAdminLoginFailure() {
        Scanner scanner = new Scanner("admin\nwrongpass\ncancel\n");
        User user = authenticator.loginAdmin(scanner);
        assertNull(user, "User should be null after failed login");
    }

    @Test
    public void testUserRegistrationSuccess() {
        Scanner scanner = new Scanner(
                "John\n" +
                        "Doe\n" +
                        "john@example.com\n" +
                        "1234567890\n" +
                        "uniqueID2\n" +
                        "johndoe2\n" +
                        "password123\n"
        );

        User user = authenticator.registerUser(scanner);

        assertNotNull(user, "User should not be null after successful registration");
        assertEquals("johndoe2", user.getUsername(), "Username should be 'johndoe2'");
    }


    @Test
    public void testUserLoginSuccess() {
        Scanner registrationScanner = new Scanner("John\nDoe\njohn@example.com\n1234567890\nuniqueID1\njohndoe1\npassword123\n");
        authenticator.registerUser(registrationScanner);

        Scanner loginScanner = new Scanner("johndoe1\npassword123\n");
        User user = authenticator.loginUser(loginScanner);

        assertNotNull(user, "User should not be null after successful login");
        assertEquals("johndoe1", user.getUsername(), "Username should be 'johndoe1'");
    }

    @Test
    public void testUserLoginFailure() {
        Scanner scanner = new Scanner("johndoe1\nwrongpassword\ncancel\n");
        User user = authenticator.loginUser(scanner);
        assertNull(user, "User should be null after failed login");
    }

    @Test
    public void testUpdateUserProfile() {
        User user = new User("John", "Doe", "john@example.com", "1234567890", "uniqueID1", "johndoe1", "password123", User.UserType.USER);
        Scanner scanner = new Scanner("3\nnewemail@example.com\n");
        authenticator.updateUserProfile(scanner, user);
        assertEquals("newemail@example.com", user.getEmail(), "Email should be updated");
    }


}
