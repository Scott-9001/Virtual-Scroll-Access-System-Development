//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//
//import java.io.ByteArrayOutputStream;
//import java.io.PrintStream;
//
//import static org.junit.jupiter.api.Assertions.assertTrue;
//
//class MainTest {
//
//    private Main mainApp;
//    private ByteArrayOutputStream outputStream;
//
//    @BeforeEach
//    void setUp() {
//        mainApp = new Main();
//
//        // Capture system output
//        outputStream = new ByteArrayOutputStream();
//        System.setOut(new PrintStream(outputStream));
//    }
//
//    @Test
//    void testInitialOutput() {
//        // Test the first lines of output when the program starts
//        mainApp.start(); // Running start()
//
//        String output = outputStream.toString();
//
//        // Verifying that expected output is present in the printed output
//        assertTrue(output.contains("Welcome to the Virtual Scroll Access System"));
//        assertTrue(output.contains("What shall you be choosing today?"));
//        assertTrue(output.contains("1. Admin Login"));
//        assertTrue(output.contains("5. Quit"));
//    }
//
//    @Test
//    void testQuitMessage() {
//        // Capture output to check if quitting outputs the correct message
//        mainApp.start(); // This will capture the printed messages.
//
//        String output = outputStream.toString();
//
//        // Checking if the quit message is printed
//        assertTrue(output.contains("Have a great day!"));
//    }
//
//    @Test
//    void testInvalidOptionOutput() {
//        // Run the program and check if invalid option message appears
//        mainApp.start(); // Running start()
//
//        String output = outputStream.toString();
//
//        // Since we can't provide inputs, just ensure invalid option exists somewhere in output
//        assertTrue(output.contains("Invalid option."));
//    }
//
//    @Test
//    void testAdminMenu() {
//        mainApp.start();
//
//        String output = outputStream.toString();
//
//        // Check if the admin menu structure is outputted correctly
//        assertTrue(output.contains("Admin"));
//        assertTrue(output.contains("Add User"));
//        assertTrue(output.contains("Delete User"));
//    }
//
//    @Test
//    void testGuestMenuOutput() {
//        mainApp.start();
//
//        String output = outputStream.toString();
//
//        // Check guest menu items
//        assertTrue(output.contains("Guest User"));
//        assertTrue(output.contains("View Scrolls"));
//    }
//
//    @Test
//    void testUserProfileUpdateOutput() {
//        mainApp.start();
//
//        String output = outputStream.toString();
//
//        // Verify that the user profile update section is printed
//        assertTrue(output.contains("Update Profile"));
//    }
//}