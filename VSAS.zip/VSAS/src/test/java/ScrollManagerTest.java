
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Scanner;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

class ScrollManagerTest {

    private ScrollManager scrollManager;
    private User adminUser;
    private User regularUser;

    @BeforeEach
    void setUp() {
        scrollManager = new ScrollManager();
        adminUser = new User("admin123", "Admin", User.UserType.ADMIN);
        regularUser = new User("user123", "RegularUser", User.UserType.USER);
    }

    @AfterEach
    void tearDown() {
        ClassLoader classLoader = ScrollManagerTest.class.getClassLoader();
        try {
            String pathString;
            File f;
            String parentPathString = classLoader.getResource("generator.sh").toURI().getPath();
            pathString = parentPathString.substring(0, parentPathString.lastIndexOf("/"));
            String ppathString = pathString.substring(0, pathString.lastIndexOf("/"));

            f = new File(ppathString + "/main/scrolls");
            for (File c : f.listFiles()) {
                c.delete();
            }
            File file = new File(ppathString + "/main/scrolls/empty.txt");
            file.createNewFile();
            File scroll = new File(ppathString + "/main/scrolls.txt");
            scroll.delete();
            scroll.createNewFile();
        } catch (Exception e) {
            return;
        }
    }

    @Test
    void testAddScroll() {
        ClassLoader classLoader = ScrollManagerTest.class.getClassLoader();
        String pathString;
        try {
            pathString = classLoader.getResource("scroll1.txt").toURI().getPath();
        } catch (Exception e) {
            return;
        }
        Scanner addScanner = new Scanner("Scroll1\n" + pathString);
        scrollManager.addScroll(addScanner, regularUser);
        // assertDoesNotThrow(() -> scrollManager.addScroll(addScanner, regularUser));
    }

    @Test
    void testAddScrollWithInvalidData() {
        Scanner invalidScanner = new Scanner("Scroll1\ninvalid_path.txt");
        scrollManager.addScroll(invalidScanner, regularUser);
        // assertDoesNotThrow(() -> scrollManager.addScroll(invalidScanner, regularUser), "Add scroll with invalid data should not throw an exception");
    }

    @Test
    void testUpdateScroll() {
        ClassLoader classLoader = ScrollManagerTest.class.getClassLoader();
        String pathString;
        try {
            pathString = classLoader.getResource("scroll1.txt").toURI().getPath();
        } catch (Exception e) {
            return;
        }
        Scanner addScanner = new Scanner("Scroll1\n" + pathString);
        scrollManager.addScroll(addScanner, regularUser);

        Scanner updateScanner = new Scanner("1\nNewScrollName\nno");
        scrollManager.updateScroll(updateScanner, regularUser);
        // assertDoesNotThrow(() -> scrollManager.updateScroll(updateScanner, regularUser));
    }

    @Test
    void testDeleteScroll() {
        ClassLoader classLoader = ScrollManagerTest.class.getClassLoader();
        String pathString;
        try {
            pathString = classLoader.getResource("scroll1.txt").toURI().getPath();
        } catch (Exception e) {
            return;
        }
        Scanner addScanner = new Scanner("Scroll1\n" + pathString);
        scrollManager.addScroll(addScanner, regularUser);

        Scanner deleteScanner = new Scanner("1\nyes\nno\ncancel");
        scrollManager.deleteScroll(deleteScanner, regularUser);
        // assertDoesNotThrow(() -> scrollManager.deleteScroll(deleteScanner, regularUser));
    }

    @Test
    void testDeleteScrollWhenNoScrollsExist() {
        Scanner deleteScanner = new Scanner("1\ncancel");
        scrollManager.deleteScroll(deleteScanner, regularUser);
        // assertDoesNotThrow(() -> scrollManager.deleteScroll(deleteScanner, regularUser), "Deleting scroll when no scrolls exist should not throw an exception");
    }

    @Test
    void testDownloadScroll() {
        ClassLoader classLoader = ScrollManagerTest.class.getClassLoader();
        String pathString;
        try {
            pathString = classLoader.getResource("scroll1.txt").toURI().getPath();
        } catch (Exception e) {
            return;
        }
        Scanner addScanner = new Scanner("Scroll1\n" + pathString);
        scrollManager.addScroll(addScanner, regularUser);

        List<Scroll> scrollList = new ArrayList<>(scrollManager.scrollsByScrollId.values());

        Scanner downloadScanner = new Scanner("1\nvalid/path");
        scrollManager.downloadScroll(downloadScanner, scrollList, regularUser);
        // assertDoesNotThrow(() -> scrollManager.downloadScroll(downloadScanner, scrollList, regularUser));
    }

    @Test
    void testDownloadScrollWithInvalidPath() {
        // Add a scroll first
        ClassLoader classLoader = ScrollManagerTest.class.getClassLoader();
        String pathString;
        try {
            pathString = classLoader.getResource("scroll1.txt").toURI().getPath();
        } catch (Exception e) {
            return;
        }
        Scanner addScanner = new Scanner("Scroll1\n" + pathString);
        scrollManager.addScroll(addScanner, regularUser);

        List<Scroll> scrollList = new ArrayList<>(scrollManager.scrollsByScrollId.values());

        Scanner invalidDownloadScanner = new Scanner("1\ninvalid/path");
        scrollManager.downloadScroll(invalidDownloadScanner, scrollList, regularUser);
        // assertDoesNotThrow(() -> scrollManager.downloadScroll(invalidDownloadScanner, scrollList, regularUser), "Download scroll with invalid path should not throw an exception");
    }

    @Test
    void testAdminCanUpdateAnyScroll() {
        // Add scroll as a regular user
        ClassLoader classLoader = ScrollManagerTest.class.getClassLoader();
        String pathString;
        try {
            pathString = classLoader.getResource("scroll9998.txt").toURI().getPath();
        } catch (Exception e) {
            return;
        }
        Scanner addScanner = new Scanner("Scroll1\n" + pathString);
        scrollManager.addScroll(addScanner, regularUser);

        Scanner updateScanner = new Scanner("1\nUpdatedScrollByAdmin\nno");
        scrollManager.updateScroll(updateScanner, adminUser);
        // assertDoesNotThrow(() -> scrollManager.updateScroll(updateScanner, adminUser), "Admin should be able to update any scroll");
    }

    @Test
    void testAddLargeNumberOfScrolls() {
        ClassLoader classLoader = ScrollManagerTest.class.getClassLoader();
        int total = 10;
        for (int i = 0; i < 10; i++) {
            String pathString;
            try {
                pathString = classLoader.getResource("scroll" + i + ".txt").toURI().getPath();
            } catch (Exception e) {
                total--;
                continue;
            }

            Scanner addScanner = new Scanner("Scroll" + i + "\n" + pathString);
            scrollManager.addScroll(addScanner, adminUser);
        }
        assertEquals(total, scrollManager.scrollsByScrollId.size(), "Should have "+ total + " scrolls added");
    }

    @Test
    void testAddUpdateAndDeleteScroll() {
        ClassLoader classLoader = ScrollManagerTest.class.getClassLoader();
        String pathString;
        try {
            pathString = classLoader.getResource("scroll9999.txt").toURI().getPath();
        } catch (Exception e) {
            return;
        }

        Scanner addScanner = new Scanner("Scroll1\n" + pathString);
        scrollManager.addScroll(addScanner, regularUser);

        Scanner updateScanner = new Scanner("1\nUpdatedScroll\nno");
        scrollManager.updateScroll(updateScanner, regularUser);
        // assertDoesNotThrow(() -> scrollManager.updateScroll(updateScanner, regularUser));

        Scanner deleteScanner = new Scanner("1\nyes\nno\ncancel");
        scrollManager.deleteScroll(deleteScanner, regularUser);
        // assertDoesNotThrow(() -> scrollManager.deleteScroll(deleteScanner, regularUser));
        assertEquals(0, scrollManager.scrollsByScrollId.size(), "Scroll should be deleted");
    }

}
